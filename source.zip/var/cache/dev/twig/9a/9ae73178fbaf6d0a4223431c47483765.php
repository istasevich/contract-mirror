<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* contract/_report.html.twig */
class __TwigTemplate_7cc2322296ac58e4cbe167b05d46f0bb extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contract/_report.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contract/_report.html.twig"));

        // line 1
        yield "<div class=\"flex flex-col gap-6\">

    ";
        // line 3
        yield from $this->load("contract/_report_header.html.twig", 3)->unwrap()->yield(CoreExtension::merge($context, ["report" =>         // line 4
(isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 4, $this->source); })()), "publicId" =>         // line 5
(isset($context["publicId"]) || array_key_exists("publicId", $context) ? $context["publicId"] : (function () { throw new RuntimeError('Variable "publicId" does not exist.', 5, $this->source); })())]));
        // line 7
        yield "    ";
        yield from $this->load("contract/_report_summary.html.twig", 7)->unwrap()->yield($context);
        // line 8
        yield "
    <div class=\"flex flex-col gap-4\">
        ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::slice($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 10, $this->source); })()), "issues", [], "any", false, false, false, 10), 0, 2));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["issue"]) {
            // line 11
            yield "            ";
            yield from $this->load("contract/_report_issue_card.html.twig", 11)->unwrap()->yield($context);
            // line 12
            yield "        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['issue'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        yield "        <div class=\"text-center text-sm text-slate-400 mt-2\">
            + ";
        // line 14
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 14, $this->source); })()), "issues", [], "any", false, false, false, 14)) - 2), "html", null, true);
        yield " more risks hidden
        </div>
    </div>

    ";
        // line 18
        if ((($tmp = (isset($context["isLocked"]) || array_key_exists("isLocked", $context) ? $context["isLocked"] : (function () { throw new RuntimeError('Variable "isLocked" does not exist.', 18, $this->source); })())) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 19
            yield "        <div class=\"relative mt-6\">
            <div class=\"absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-transparent\">
                ";
            // line 21
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::slice($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 21, $this->source); })()), "issues", [], "any", false, false, false, 21), 2));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["issue"]) {
                // line 22
                yield "                    ";
                yield from $this->load("contract/_report_issue_card.html.twig", 22)->unwrap()->yield($context);
                // line 23
                yield "                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['issue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 24
            yield "
                ";
            // line 25
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 25, $this->source); })()), "missingProtections", [], "any", false, false, false, 25));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 26
                yield "                    ";
                yield from $this->load("contract/_report_missing_protection_card.html.twig", 26)->unwrap()->yield(CoreExtension::merge($context, ["protection" =>                 // line 27
$context["item"]]));
                // line 29
                yield "                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 30
            yield "            </div>

            <div class=\"absolute inset-0 flex items-center justify-center\">
                <div class=\"bg-slate-900 border border-white/10 rounded-2xl p-6 text-center max-w-md\">
                    <div class=\"text-sm text-slate-300 mb-4\">
                        You’re seeing only <strong>30% of the analysis</strong>.

                        <div class=\"mt-2 text-slate-400\">
                            Unlock full report to:
                            <ul class=\"mt-2 space-y-1 text-left\">
                                <li>• See all hidden risks</li>
                                <li>• Fix dangerous clauses instantly</li>
                                <li>• Understand what you might lose</li>
                                <li>• 📄 Download professional PDF</li>
                            </ul>
                        </div>
                    </div>

                    ";
            // line 48
            if ((($tmp = (isset($context["payment"]) || array_key_exists("payment", $context) ? $context["payment"] : (function () { throw new RuntimeError('Variable "payment" does not exist.', 48, $this->source); })())) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 49
                yield "                        <button
                            onclick=\"openPaymentModal()\"
                            class=\"bg-violet-500 hover:bg-violet-600 text-white px-6 py-3 rounded-xl font-bold\"
                        >
                            🔓 Unlock a full report — ";
                // line 53
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["payment"]) || array_key_exists("payment", $context) ? $context["payment"] : (function () { throw new RuntimeError('Variable "payment" does not exist.', 53, $this->source); })()), "amount", [], "any", false, false, false, 53), "html", null, true);
                yield " ";
                yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["payment"]) || array_key_exists("payment", $context) ? $context["payment"] : (function () { throw new RuntimeError('Variable "payment" does not exist.', 53, $this->source); })()), "currency", [], "any", false, false, false, 53), "html", null, true);
                yield "
                        </button>
                    ";
            } else {
                // line 56
                yield "                        <div class=\"rounded-xl border border-red-400/20 bg-red-500/10 px-4 py-3 text-sm text-red-200\">
                            Payment is unavailable right now. Please refresh the page.
                        </div>
                    ";
            }
            // line 60
            yield "                </div>
            </div>
        </div>
    ";
        } else {
            // line 64
            yield "        <div class=\"flex flex-col gap-4 mt-6\">
            ";
            // line 65
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::slice($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 65, $this->source); })()), "issues", [], "any", false, false, false, 65), 2));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["issue"]) {
                // line 66
                yield "                ";
                yield from $this->load("contract/_report_issue_card.html.twig", 66)->unwrap()->yield($context);
                // line 67
                yield "            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['issue'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 68
            yield "
            ";
            // line 69
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 69, $this->source); })()), "missingProtections", [], "any", false, false, false, 69));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 70
                yield "                ";
                yield from $this->load("contract/_report_missing_protection_card.html.twig", 70)->unwrap()->yield(CoreExtension::merge($context, ["protection" =>                 // line 71
$context["item"]]));
                // line 73
                yield "            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 74
            yield "        </div>
    ";
        }
        // line 76
        yield "
</div>

";
        // line 79
        if (((isset($context["isLocked"]) || array_key_exists("isLocked", $context) ? $context["isLocked"] : (function () { throw new RuntimeError('Variable "isLocked" does not exist.', 79, $this->source); })()) && (isset($context["payment"]) || array_key_exists("payment", $context) ? $context["payment"] : (function () { throw new RuntimeError('Variable "payment" does not exist.', 79, $this->source); })()))) {
            // line 80
            yield "    <div id=\"payment-modal\" class=\"hidden fixed inset-0 z-50 flex items-center justify-center bg-black/70\">
        <div class=\"w-full max-w-md rounded-2xl bg-slate-900 p-6 border border-white/10\">
            <h2 class=\"text-xl font-bold text-white mb-4\">
                🔓 Unlock full report
            </h2>

            <p class=\"text-slate-400 mb-4\">
                Send <strong>";
            // line 87
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["payment"]) || array_key_exists("payment", $context) ? $context["payment"] : (function () { throw new RuntimeError('Variable "payment" does not exist.', 87, $this->source); })()), "amount", [], "any", false, false, false, 87), "html", null, true);
            yield " ";
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["payment"]) || array_key_exists("payment", $context) ? $context["payment"] : (function () { throw new RuntimeError('Variable "payment" does not exist.', 87, $this->source); })()), "currency", [], "any", false, false, false, 87), "html", null, true);
            yield "</strong>
            </p>

            <div class=\"bg-black/40 rounded-xl p-3 text-center text-green-400 font-mono text-sm break-all\">
                ";
            // line 91
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["payment"]) || array_key_exists("payment", $context) ? $context["payment"] : (function () { throw new RuntimeError('Variable "payment" does not exist.', 91, $this->source); })()), "address", [], "any", false, false, false, 91), "html", null, true);
            yield "
            </div>

            <p class=\"text-xs text-slate-500 mt-2 text-center\">
                Network: TRC20
            </p>

            <input
                id=\"tx-hash-input\"
                type=\"text\"
                placeholder=\"Paste transaction hash\"
                class=\"mt-4 w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2 text-sm text-white\"
            />

            <button
                onclick=\"submitPayment()\"
                class=\"mt-4 w-full bg-violet-500 hover:bg-violet-600 text-white py-3 rounded-xl font-bold\"
            >
                Submit payment
            </button>

            <button
                onclick=\"closePaymentModal()\"
                class=\"mt-2 w-full text-sm text-slate-400\"
            >
                Cancel
            </button>
        </div>
    </div>
";
        }
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "contract/_report.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  337 => 91,  328 => 87,  319 => 80,  317 => 79,  312 => 76,  308 => 74,  294 => 73,  292 => 71,  290 => 70,  273 => 69,  270 => 68,  256 => 67,  253 => 66,  236 => 65,  233 => 64,  227 => 60,  221 => 56,  213 => 53,  207 => 49,  205 => 48,  185 => 30,  171 => 29,  169 => 27,  167 => 26,  150 => 25,  147 => 24,  133 => 23,  130 => 22,  113 => 21,  109 => 19,  107 => 18,  100 => 14,  97 => 13,  83 => 12,  80 => 11,  63 => 10,  59 => 8,  56 => 7,  54 => 5,  53 => 4,  52 => 3,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<div class=\"flex flex-col gap-6\">

    {% include 'contract/_report_header.html.twig' with {
        report: report,
        publicId: publicId
    } %}
    {% include 'contract/_report_summary.html.twig' %}

    <div class=\"flex flex-col gap-4\">
        {% for issue in report.issues|slice(0, 2) %}
            {% include 'contract/_report_issue_card.html.twig' %}
        {% endfor %}
        <div class=\"text-center text-sm text-slate-400 mt-2\">
            + {{ report.issues|length - 2 }} more risks hidden
        </div>
    </div>

    {% if isLocked %}
        <div class=\"relative mt-6\">
            <div class=\"absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-transparent\">
                {% for issue in report.issues|slice(2) %}
                    {% include 'contract/_report_issue_card.html.twig' %}
                {% endfor %}

                {% for item in report.missingProtections %}
                    {% include 'contract/_report_missing_protection_card.html.twig' with {
                        protection: item
                    } %}
                {% endfor %}
            </div>

            <div class=\"absolute inset-0 flex items-center justify-center\">
                <div class=\"bg-slate-900 border border-white/10 rounded-2xl p-6 text-center max-w-md\">
                    <div class=\"text-sm text-slate-300 mb-4\">
                        You’re seeing only <strong>30% of the analysis</strong>.

                        <div class=\"mt-2 text-slate-400\">
                            Unlock full report to:
                            <ul class=\"mt-2 space-y-1 text-left\">
                                <li>• See all hidden risks</li>
                                <li>• Fix dangerous clauses instantly</li>
                                <li>• Understand what you might lose</li>
                                <li>• 📄 Download professional PDF</li>
                            </ul>
                        </div>
                    </div>

                    {% if payment %}
                        <button
                            onclick=\"openPaymentModal()\"
                            class=\"bg-violet-500 hover:bg-violet-600 text-white px-6 py-3 rounded-xl font-bold\"
                        >
                            🔓 Unlock a full report — {{ payment.amount }} {{ payment.currency }}
                        </button>
                    {% else %}
                        <div class=\"rounded-xl border border-red-400/20 bg-red-500/10 px-4 py-3 text-sm text-red-200\">
                            Payment is unavailable right now. Please refresh the page.
                        </div>
                    {% endif %}
                </div>
            </div>
        </div>
    {% else %}
        <div class=\"flex flex-col gap-4 mt-6\">
            {% for issue in report.issues|slice(2) %}
                {% include 'contract/_report_issue_card.html.twig' %}
            {% endfor %}

            {% for item in report.missingProtections %}
                {% include 'contract/_report_missing_protection_card.html.twig' with {
                    protection: item
                } %}
            {% endfor %}
        </div>
    {% endif %}

</div>

{% if isLocked and payment %}
    <div id=\"payment-modal\" class=\"hidden fixed inset-0 z-50 flex items-center justify-center bg-black/70\">
        <div class=\"w-full max-w-md rounded-2xl bg-slate-900 p-6 border border-white/10\">
            <h2 class=\"text-xl font-bold text-white mb-4\">
                🔓 Unlock full report
            </h2>

            <p class=\"text-slate-400 mb-4\">
                Send <strong>{{ payment.amount }} {{ payment.currency }}</strong>
            </p>

            <div class=\"bg-black/40 rounded-xl p-3 text-center text-green-400 font-mono text-sm break-all\">
                {{ payment.address }}
            </div>

            <p class=\"text-xs text-slate-500 mt-2 text-center\">
                Network: TRC20
            </p>

            <input
                id=\"tx-hash-input\"
                type=\"text\"
                placeholder=\"Paste transaction hash\"
                class=\"mt-4 w-full rounded-xl bg-white/5 border border-white/10 px-3 py-2 text-sm text-white\"
            />

            <button
                onclick=\"submitPayment()\"
                class=\"mt-4 w-full bg-violet-500 hover:bg-violet-600 text-white py-3 rounded-xl font-bold\"
            >
                Submit payment
            </button>

            <button
                onclick=\"closePaymentModal()\"
                class=\"mt-2 w-full text-sm text-slate-400\"
            >
                Cancel
            </button>
        </div>
    </div>
{% endif %}
", "contract/_report.html.twig", "/var/www/html/templates/contract/_report.html.twig");
    }
}
