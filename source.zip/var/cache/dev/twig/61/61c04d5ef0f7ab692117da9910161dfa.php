<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* contract/_report_missing_protection_card.html.twig */
class __TwigTemplate_19e4f326ef5c7c2097b49318d3e90a3b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contract/_report_missing_protection_card.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contract/_report_missing_protection_card.html.twig"));

        // line 1
        yield "
<article class=\"rounded-[28px] border border-violet-400/20 bg-violet-400/10 p-6\">
    <div class=\"mb-2 flex flex-wrap gap-2\">
        <span class=\"rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs text-violet-100\">Missing protection</span>
        <span class=\"rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs text-violet-100\">";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["protection"]) || array_key_exists("protection", $context) ? $context["protection"] : (function () { throw new RuntimeError('Variable "protection" does not exist.', 5, $this->source); })()), "category", [], "any", false, false, false, 5), "html", null, true);
        yield "</span>
    </div>

    <h4 class=\"text-xl font-bold text-white\">";
        // line 8
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["protection"]) || array_key_exists("protection", $context) ? $context["protection"] : (function () { throw new RuntimeError('Variable "protection" does not exist.', 8, $this->source); })()), "title", [], "any", false, false, false, 8), "html", null, true);
        yield "</h4>
    <p class=\"mt-3 text-sm text-slate-100\">";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["protection"]) || array_key_exists("protection", $context) ? $context["protection"] : (function () { throw new RuntimeError('Variable "protection" does not exist.', 9, $this->source); })()), "whyItMatters", [], "any", false, false, false, 9), "html", null, true);
        yield "</p>

    ";
        // line 11
        if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, (isset($context["protection"]) || array_key_exists("protection", $context) ? $context["protection"] : (function () { throw new RuntimeError('Variable "protection" does not exist.', 11, $this->source); })()), "suggestedClause", [], "any", false, false, false, 11))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 12
            yield "        <div class=\"mt-4 rounded-2xl border border-white/10 bg-slate-950/40 p-4\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-violet-200\">Suggested clause</div>
            <p class=\"mt-2 whitespace-pre-line text-sm text-slate-100\">";
            // line 14
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["protection"]) || array_key_exists("protection", $context) ? $context["protection"] : (function () { throw new RuntimeError('Variable "protection" does not exist.', 14, $this->source); })()), "suggestedClause", [], "any", false, false, false, 14), "html", null, true);
            yield "</p>
        </div>
    ";
        }
        // line 17
        yield "</article>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "contract/_report_missing_protection_card.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  81 => 17,  75 => 14,  71 => 12,  69 => 11,  64 => 9,  60 => 8,  54 => 5,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("
<article class=\"rounded-[28px] border border-violet-400/20 bg-violet-400/10 p-6\">
    <div class=\"mb-2 flex flex-wrap gap-2\">
        <span class=\"rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs text-violet-100\">Missing protection</span>
        <span class=\"rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs text-violet-100\">{{ protection.category }}</span>
    </div>

    <h4 class=\"text-xl font-bold text-white\">{{ protection.title }}</h4>
    <p class=\"mt-3 text-sm text-slate-100\">{{ protection.whyItMatters }}</p>

    {% if protection.suggestedClause is not empty %}
        <div class=\"mt-4 rounded-2xl border border-white/10 bg-slate-950/40 p-4\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-violet-200\">Suggested clause</div>
            <p class=\"mt-2 whitespace-pre-line text-sm text-slate-100\">{{ protection.suggestedClause }}</p>
        </div>
    {% endif %}
</article>
", "contract/_report_missing_protection_card.html.twig", "/var/www/html/templates/contract/_report_missing_protection_card.html.twig");
    }
}
