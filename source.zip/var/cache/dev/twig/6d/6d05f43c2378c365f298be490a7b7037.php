<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* contract/_report_summary.html.twig */
class __TwigTemplate_b3a2d5c6c1f01c9ffc049b0636581d23 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contract/_report_summary.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contract/_report_summary.html.twig"));

        // line 1
        yield "
<section class=\"grid gap-4 lg:grid-cols-[.92fr_1.08fr]\">
    <div class=\"rounded-[28px] border border-white/10 bg-white/5 p-6\">
        <div class=\"text-sm font-semibold uppercase tracking-[0.18em] text-slate-400\">Executive summary</div>
        <p class=\"mt-4 text-slate-200\">";
        // line 5
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 5, $this->source); })()), "executiveSummary", [], "any", false, false, false, 5), "html", null, true);
        yield "</p>
    </div>

    <div class=\"rounded-[28px] border border-cyan-400/20 bg-cyan-400/10 p-6\">
        <div class=\"text-sm font-semibold uppercase tracking-[0.18em] text-cyan-200\">Final recommendation</div>
        <div class=\"mt-4 text-xl font-bold text-white\">";
        // line 10
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 10, $this->source); })()), "finalRecommendation", [], "any", false, false, false, 10), "html", null, true);
        yield "</div>
        <p class=\"mt-3 text-slate-100\">";
        // line 11
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 11, $this->source); })()), "signingRecommendation", [], "any", false, false, false, 11), "html", null, true);
        yield "</p>
    </div>
</section>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "contract/_report_summary.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  66 => 11,  62 => 10,  54 => 5,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("
<section class=\"grid gap-4 lg:grid-cols-[.92fr_1.08fr]\">
    <div class=\"rounded-[28px] border border-white/10 bg-white/5 p-6\">
        <div class=\"text-sm font-semibold uppercase tracking-[0.18em] text-slate-400\">Executive summary</div>
        <p class=\"mt-4 text-slate-200\">{{ report.executiveSummary }}</p>
    </div>

    <div class=\"rounded-[28px] border border-cyan-400/20 bg-cyan-400/10 p-6\">
        <div class=\"text-sm font-semibold uppercase tracking-[0.18em] text-cyan-200\">Final recommendation</div>
        <div class=\"mt-4 text-xl font-bold text-white\">{{ report.finalRecommendation }}</div>
        <p class=\"mt-3 text-slate-100\">{{ report.signingRecommendation }}</p>
    </div>
</section>
", "contract/_report_summary.html.twig", "/var/www/html/templates/contract/_report_summary.html.twig");
    }
}
