<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* landing/index.html.twig */
class __TwigTemplate_fd3748c6d656666e714f74a173d45cf6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "landing/index.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "landing/index.html.twig"));

        // line 1
        yield "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
    <title>ContractMirror.ai — Check freelance contracts before signing</title>
    <script src=\"https://cdn.tailwindcss.com\"></script>
    <style>
        html { scroll-behavior: smooth; }

        body {
            background:
                radial-gradient(circle at top center, rgba(56, 189, 248, 0.16), transparent 34%),
                radial-gradient(circle at 20% 20%, rgba(99, 102, 241, 0.18), transparent 24%),
                radial-gradient(circle at 80% 10%, rgba(59, 130, 246, 0.12), transparent 20%),
                #0b132b;
        }

        .glass {
            background: rgba(15, 23, 42, 0.72);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
        }

        .grid-fade {
            background-image:
                linear-gradient(rgba(148,163,184,.08) 1px, transparent 1px),
                linear-gradient(90deg, rgba(148,163,184,.08) 1px, transparent 1px);
            background-size: 32px 32px;
            mask-image: radial-gradient(circle at center, black 45%, transparent 90%);
            -webkit-mask-image: radial-gradient(circle at center, black 45%, transparent 90%);
        }
    </style>
</head>
<body class=\"text-slate-200 font-sans leading-relaxed antialiased\">
";
        // line 36
        $context["hasInitialReport"] = (array_key_exists("initialReportHtml", $context) &&  !Twig\Extension\CoreExtension::testEmpty((isset($context["initialReportHtml"]) || array_key_exists("initialReportHtml", $context) ? $context["initialReportHtml"] : (function () { throw new RuntimeError('Variable "initialReportHtml" does not exist.', 36, $this->source); })())));
        // line 37
        yield "
<div class=\"fixed inset-0 grid-fade pointer-events-none\"></div>

<header class=\"sticky top-0 z-50 border-b border-white/10 bg-slate-950/40 backdrop-blur-xl\">
    <div class=\"mx-auto flex max-w-7xl items-center justify-between px-6 py-4\">
        <a href=\"#top\" class=\"flex items-center gap-3\">
            <div class=\"h-10 w-3 rounded-full bg-gradient-to-b from-violet-400 to-cyan-400 shadow-[0_0_24px_rgba(99,102,241,.45)]\"></div>
            <span class=\"text-2xl font-black tracking-tight text-white\">
                ContractMirror<span class=\"text-violet-400\">.ai</span>
            </span>
        </a>

        <nav class=\"hidden items-center gap-8 text-sm font-semibold text-slate-300 md:flex\">
            <a href=\"#problem\" class=\"transition hover:text-white\">Why it matters</a>
            <a href=\"#how\" class=\"transition hover:text-white\">How it works</a>
            <a href=\"#report\" class=\"transition hover:text-white\">Sample report</a>
            <a href=\"#live-report\" class=\"transition hover:text-white\">Live result</a>
        </nav>

        <a href=\"#analyze\" class=\"rounded-full bg-gradient-to-r from-violet-500 to-indigo-500 px-5 py-2.5 text-sm font-bold text-white shadow-[0_0_30px_rgba(99,102,241,.35)] transition hover:-translate-y-0.5\">
            Get Started
        </a>
    </div>
</header>

<main id=\"top\">
    <section class=\"relative overflow-hidden\">
        <div class=\"mx-auto max-w-7xl px-6 pb-24 pt-20 lg:pb-28 lg:pt-28\">
            <div class=\"mx-auto max-w-5xl text-center\">
                <div class=\"mb-6 inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-sm font-medium text-cyan-200\">
                    AI contract risk analysis for freelancers, developers, designers, and agencies
                </div>

                <h1 class=\"mx-auto max-w-4xl text-5xl font-black tracking-tight text-white md:text-7xl\">
                    Check freelance contracts
                    <span class=\"bg-gradient-to-r from-violet-400 via-sky-400 to-cyan-300 bg-clip-text text-transparent\">
                        before signing
                    </span>
                </h1>

                <p class=\"mx-auto mt-6 max-w-3xl text-lg text-slate-300 md:text-xl\">
                    Upload a contract and get a clear risk score, red flags, rewrite suggestions, and a structured summary in seconds.
                    ContractMirror explains legal meaning in plain language, even when the contract is written in another language.
                </p>

                <div class=\"mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row\">
                    <a href=\"#analyze\" class=\"inline-flex min-w-[220px] items-center justify-center rounded-2xl bg-gradient-to-r from-violet-500 to-indigo-500 px-7 py-4 text-base font-bold text-white shadow-[0_0_36px_rgba(99,102,241,.35)] transition hover:-translate-y-0.5\">
                        Analyze your contract
                    </a>
                    <a href=\"#live-report\" class=\"inline-flex min-w-[220px] items-center justify-center rounded-2xl border border-white/15 bg-white/5 px-7 py-4 text-base font-bold text-slate-200 transition hover:bg-white/10\">
                        See live report layout
                    </a>
                </div>
            </div>

            <div class=\"mt-16 grid gap-8 lg:grid-cols-[1.1fr_.9fr] lg:items-start\">
                <div id=\"analyze\" class=\"glass rounded-[28px] border border-white/10 p-8 shadow-2xl shadow-slate-950/40\">
                    <div class=\"mb-6 flex items-start justify-between gap-4\">
                        <div>
                            <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-slate-400\">Upload & scan</div>
                            <h2 class=\"mt-2 text-2xl font-bold text-white\">Drop your PDF, DOCX, or TXT here</h2>
                            <p class=\"mt-2 text-slate-400\">Private by default. Encrypted in transit. Max file size 10 MB in MVP.</p>
                        </div>
                        <div class=\"rounded-2xl border border-violet-400/20 bg-violet-400/10 px-3 py-2 text-xs font-bold uppercase tracking-[0.2em] text-violet-200\">
                            Fast AI review
                        </div>
                    </div>

                    <form
                        id=\"analyze-contract-form\"
                        method=\"POST\"
                        enctype=\"multipart/form-data\"
                        class=\"rounded-[24px] border-2 border-dashed border-slate-700 bg-slate-900/60 p-8 text-center transition hover:border-violet-400/60\"
                    >
                        <div class=\"mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-3xl bg-slate-800 text-4xl shadow-inner\">
                            ☁️
                        </div>

                        <p class=\"text-xl font-bold text-white\">Drop your contract here</p>
                        <p class=\"mt-2 text-slate-400\">Choose a file and get a clear verdict, top risks, and safer wording suggestions.</p>

                        <input
                            id=\"contract-file-input\"
                            type=\"file\"
                            name=\"contractFile\"
                            class=\"hidden\"
                            accept=\".pdf,.docx,.txt\"
                        >

                        <div class=\"mt-6\">
                            <label for=\"preferredLanguage\" class=\"mb-2 block text-sm font-medium text-slate-300\">
                                Analysis language
                            </label>

                            <select
                                id=\"preferredLanguage\"
                                name=\"preferredLanguage\"
                                class=\"w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-slate-200 outline-none transition focus:border-violet-400\"
                            >
                                <option value=\"English\">English</option>
                                <option value=\"Ukrainian\">Ukrainian</option>
                                <option value=\"German\">German</option>
                                <option value=\"Spanish\">Spanish</option>
                                <option value=\"Italian\">Italian</option>
                                <option value=\"French\">French</option>
                                <option value=\"Turkish\">Turkish</option>
                                <option value=\"Greek\">Greek</option>
                                <option value=\"Polish\">Polish</option>
                                <option value=\"Russian\">Russian</option>
                            </select>
                        </div>

                        <div id=\"selected-file-name\" class=\"mt-4 text-sm text-slate-400\">
                            No file selected
                        </div>

                        <div class=\"mt-8 grid gap-3 sm:grid-cols-2\">
                            <button
                                type=\"button\"
                                id=\"upload-contract-trigger\"
                                class=\"rounded-2xl bg-gradient-to-r from-violet-500 to-indigo-500 px-6 py-4 font-bold text-white shadow-[0_0_24px_rgba(99,102,241,.3)] transition hover:-translate-y-0.5\"
                            >
                                Upload contract
                            </button>

                            <button
                                type=\"submit\"
                                id=\"analyze-submit-button\"
                                class=\"rounded-2xl border border-white/10 bg-white/5 px-6 py-4 font-bold text-slate-200 transition hover:bg-white/10\"
                            >
                                Analyze contract
                            </button>
                        </div>

                        <div id=\"form-status\" class=\"mt-5 hidden rounded-2xl border px-4 py-3 text-sm\"></div>

                        <p class=\"mt-5 text-xs uppercase tracking-[0.24em] text-slate-500\">
                            Informational AI analysis. Not legal advice.
                        </p>
                    </form>

                    <div class=\"mt-6 text-center\">
                        <p class=\"text-sm text-slate-400 mb-2\">
                            See a real example report
                        </p>

                        <a
                            href=\"/demo/contract-report-example.pdf\"
                            target=\"_blank\"
                            class=\"inline-flex items-center justify-center rounded-xl border border-white/10 bg-white/5 px-5 py-3 text-sm font-semibold text-slate-200 transition hover:bg-white/10\"
                        >
                            View Sample PDF →
                        </a>

                        <p class=\"mt-2 text-xs text-slate-500\">
                            No signup required • Takes ~30 seconds
                        </p>
                    </div>

                    <div class=\"mt-8 grid gap-3 sm:grid-cols-3\">
                        <div class=\"rounded-2xl border border-white/10 bg-white/5 p-4\">
                            <div class=\"text-sm text-slate-400\">Average scan time</div>
                            <div class=\"mt-2 text-xl font-bold text-white\">~30 sec</div>
                        </div>
                        <div class=\"rounded-2xl border border-white/10 bg-white/5 p-4\">
                            <div class=\"text-sm text-slate-400\">Output</div>
                            <div class=\"mt-2 text-xl font-bold text-white\">Risk + fixes</div>
                        </div>
                        <div class=\"rounded-2xl border border-white/10 bg-white/5 p-4\">
                            <div class=\"text-sm text-slate-400\">Built for</div>
                            <div class=\"mt-2 text-xl font-bold text-white\">Freelancers</div>
                        </div>
                    </div>
                </div>

                <section id=\"report\" class=\"glass rounded-[28px] border border-white/10 p-6 shadow-2xl shadow-slate-950/40\">
                    <div class=\"flex items-center justify-between gap-4 border-b border-white/10 pb-5\">
                        <div>
                            <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-slate-400\">Sample output</div>
                            <h3 class=\"mt-2 text-xl font-bold text-white\">Contract risk snapshot</h3>
                        </div>
                        <span class=\"rounded-full border border-orange-400/20 bg-orange-400/10 px-3 py-1 text-xs font-bold uppercase tracking-[0.18em] text-orange-300\">
                            Medium risk
                        </span>
                    </div>

                    <div class=\"mt-6 rounded-[24px] border border-white/10 bg-slate-950/50 p-6\">
                        <div class=\"flex items-end justify-between gap-4\">
                            <div>
                                <div class=\"text-sm text-slate-400\">Contract Risk Score</div>
                                <div class=\"mt-2 text-5xl font-black tracking-tight text-white\">
                                    6.4<span class=\"text-xl text-slate-500\"> / 10</span>
                                </div>
                            </div>
                            <div class=\"rounded-2xl border border-violet-400/20 bg-violet-400/10 px-3 py-2 text-sm font-bold text-violet-200\">
                                Needs review
                            </div>
                        </div>

                        <div class=\"mt-6\">
                            <div class=\"mb-2 flex items-center justify-between text-xs font-bold uppercase tracking-[0.18em] text-slate-400\">
                                <span>Safe</span>
                                <span>Warning</span>
                                <span>Dangerous</span>
                            </div>
                            <div class=\"h-3 overflow-hidden rounded-full bg-slate-800\">
                                <div class=\"h-full w-[64%] rounded-full bg-gradient-to-r from-emerald-400 via-amber-400 to-red-500\"></div>
                            </div>
                        </div>

                        <div class=\"mt-6 space-y-4\">
                            <div class=\"rounded-2xl border border-red-400/20 bg-red-500/10 p-4\">
                                <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-red-300\">Flagged clause</div>
                                <p class=\"mt-2 text-sm text-slate-200\">
                                    “Contractor agrees to modify deliverables until the client is fully satisfied.”
                                </p>
                            </div>

                            <div class=\"rounded-2xl border border-cyan-400/20 bg-cyan-400/10 p-4\">
                                <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-cyan-200\">Plain explanation</div>
                                <p class=\"mt-2 text-sm text-slate-100\">
                                    This wording gives the client very broad power to keep asking for changes without a clear stopping point or additional payment terms.
                                </p>
                            </div>

                            <div class=\"rounded-2xl border border-violet-400/20 bg-violet-400/10 p-4\">
                                <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-violet-200\">Suggested rewrite</div>
                                <p class=\"mt-2 text-sm text-slate-100\">
                                    “The agreed price includes up to 2 revision rounds. Additional revision requests are billed separately at the contractor’s standard hourly rate.”
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <div class=\"mt-10 flex flex-wrap items-center justify-center gap-4 text-sm text-slate-400\">
                <span class=\"rounded-full border border-white/10 bg-white/5 px-4 py-2\">Built for developers</span>
                <span class=\"rounded-full border border-white/10 bg-white/5 px-4 py-2\">Designers</span>
                <span class=\"rounded-full border border-white/10 bg-white/5 px-4 py-2\">Agencies</span>
                <span class=\"rounded-full border border-white/10 bg-white/5 px-4 py-2\">Remote pros</span>
                <span class=\"rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-cyan-200\">
                    Cross-language contract support
                </span>
            </div>
        </div>
    </section>

    <section id=\"problem\" class=\"py-24\">
        <div class=\"mx-auto max-w-7xl px-6\">
            <div class=\"grid gap-8 lg:grid-cols-[1fr_1fr] lg:items-center\">
                <div>
                    <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-cyan-300\">Cross-language clarity</div>
                    <h2 class=\"mt-4 text-4xl font-black tracking-tight text-white md:text-5xl\">
                        Understand contracts across languages
                    </h2>
                    <p class=\"mt-5 text-lg text-slate-400\">
                        Upload contracts written in German, Polish, Spanish, or English. ContractMirror explains the legal meaning
                        in plain language, so users can understand what they are agreeing to without guessing or translating clause by clause.
                    </p>
                </div>
                <div class=\"grid gap-4 sm:grid-cols-3\">
                    <div class=\"rounded-3xl border border-white/10 bg-white/5 p-5\">
                        <div class=\"text-sm uppercase tracking-[0.2em] text-slate-400\">Original clause</div>
                        <div class=\"mt-3 text-sm text-white\">Legal wording as written in the contract.</div>
                    </div>
                    <div class=\"rounded-3xl border border-cyan-400/20 bg-cyan-400/10 p-5\">
                        <div class=\"text-sm uppercase tracking-[0.2em] text-cyan-200\">Plain explanation</div>
                        <div class=\"mt-3 text-sm text-cyan-50\">Human-readable meaning, in the user’s preferred language.</div>
                    </div>
                    <div class=\"rounded-3xl border border-violet-400/20 bg-violet-400/10 p-5\">
                        <div class=\"text-sm uppercase tracking-[0.2em] text-violet-200\">Safer wording</div>
                        <div class=\"mt-3 text-sm text-violet-50\">Concrete wording the user can propose back.</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id=\"how\" class=\"pb-24\">
        <div class=\"mx-auto max-w-7xl px-6\">
            <div class=\"mb-8\">
                <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-violet-300\">How it works</div>
                <h2 class=\"mt-4 text-4xl font-black tracking-tight text-white md:text-5xl\">
                    From upload to decision in minutes
                </h2>
            </div>
            <div class=\"grid gap-4 md:grid-cols-3\">
                <div class=\"rounded-3xl border border-white/10 bg-white/5 p-6\">
                    <div class=\"mb-3 text-sm font-bold uppercase tracking-[0.18em] text-cyan-200\">1. Upload</div>
                    <p class=\"text-slate-300\">Upload a PDF, DOCX, or TXT contract and choose the output language.</p>
                </div>
                <div class=\"rounded-3xl border border-white/10 bg-white/5 p-6\">
                    <div class=\"mb-3 text-sm font-bold uppercase tracking-[0.18em] text-cyan-200\">2. Analyze</div>
                    <p class=\"text-slate-300\">ContractMirror extracts the text, analyzes risk, and builds a structured report.</p>
                </div>
                <div class=\"rounded-3xl border border-white/10 bg-white/5 p-6\">
                    <div class=\"mb-3 text-sm font-bold uppercase tracking-[0.18em] text-cyan-200\">3. Decide</div>
                    <p class=\"text-slate-300\">See the verdict, understand why it matters, and use safer wording suggestions.</p>
                </div>
            </div>
        </div>
    </section>

    <section id=\"live-report\" class=\"pb-24\">
        <div class=\"mx-auto max-w-7xl px-6\">
            <div class=\"mb-8 max-w-3xl\">
                <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-violet-300\">Live report</div>
                <h2 class=\"mt-4 text-4xl font-black tracking-tight text-white md:text-5xl\">
                    Beautiful verdict view, not raw JSON
                </h2>
                <p class=\"mt-4 text-lg text-slate-400\">
                    The analysis result appears here after upload, with a simple view for quick decisions and a detailed view for clause-by-clause review.
                </p>
            </div>

            <div id=\"report-shell\" class=\"glass rounded-[32px] border border-white/10 p-6 shadow-2xl shadow-slate-950/40\">
                <div class=\"flex flex-col gap-4 border-b border-white/10 pb-6 md:flex-row md:items-center md:justify-between\">
                    <div>
                        <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-slate-400\">Analysis report</div>
                        <h3 id=\"report-title\" class=\"mt-2 text-2xl font-bold text-white\">
                            ";
        // line 358
        yield (((($tmp = (isset($context["hasInitialReport"]) || array_key_exists("hasInitialReport", $context) ? $context["hasInitialReport"] : (function () { throw new RuntimeError('Variable "hasInitialReport" does not exist.', 358, $this->source); })())) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("initialReportTitle", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["initialReportTitle"]) || array_key_exists("initialReportTitle", $context) ? $context["initialReportTitle"] : (function () { throw new RuntimeError('Variable "initialReportTitle" does not exist.', 358, $this->source); })()), "Contract analysis report")) : ("Contract analysis report")), "html", null, true)) : ("No report yet"));
        yield "
                        </h3>
                        <p id=\"report-subtitle\" class=\"mt-2 text-slate-400\">
                            ";
        // line 361
        yield (((($tmp = (isset($context["hasInitialReport"]) || array_key_exists("hasInitialReport", $context) ? $context["hasInitialReport"] : (function () { throw new RuntimeError('Variable "hasInitialReport" does not exist.', 361, $this->source); })())) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("initialReportSubtitle", $context)) ? (Twig\Extension\CoreExtension::default((isset($context["initialReportSubtitle"]) || array_key_exists("initialReportSubtitle", $context) ? $context["initialReportSubtitle"] : (function () { throw new RuntimeError('Variable "initialReportSubtitle" does not exist.', 361, $this->source); })()), "Review the verdict, risks, and suggested fixes.")) : ("Review the verdict, risks, and suggested fixes.")), "html", null, true)) : ("Upload a contract above and the structured report will appear here."));
        yield "
                        </p>
                    </div>

                    <div class=\"flex gap-3\">
                        <button id=\"simple-view-button\" type=\"button\" class=\"rounded-2xl border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-sm font-bold text-cyan-100\">
                            Simple view
                        </button>
                        <button id=\"detailed-view-button\" type=\"button\" class=\"rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-bold text-slate-300\">
                            Detailed view
                        </button>
                    </div>
                </div>

                <div id=\"report-empty-state\" class=\"";
        // line 375
        if ((($tmp = (isset($context["hasInitialReport"]) || array_key_exists("hasInitialReport", $context) ? $context["hasInitialReport"] : (function () { throw new RuntimeError('Variable "hasInitialReport" does not exist.', 375, $this->source); })())) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "hidden ";
        }
        yield "py-12 text-center\">
                    <div class=\"mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-slate-800 text-3xl\">🪞</div>
                    <h4 class=\"mt-5 text-xl font-bold text-white\">Ready for your first contract</h4>
                    <p class=\"mx-auto mt-3 max-w-2xl text-slate-400\">
                        You will get a risk score, plain-language summary, top issues, missing protections, and a final recommendation.
                    </p>
                </div>

                <div id=\"report-loading-state\" class=\"hidden py-12\">
                    <div class=\"mx-auto max-w-3xl animate-pulse space-y-4\">
                        <div class=\"h-6 w-48 rounded-xl bg-white/10\"></div>
                        <div class=\"h-20 rounded-3xl bg-white/5\"></div>
                        <div class=\"grid gap-4 md:grid-cols-3\">
                            <div class=\"h-32 rounded-3xl bg-white/5\"></div>
                            <div class=\"h-32 rounded-3xl bg-white/5\"></div>
                            <div class=\"h-32 rounded-3xl bg-white/5\"></div>
                        </div>
                    </div>
                </div>

                <div id=\"report-content\" class=\"";
        // line 395
        if ((($tmp =  !(isset($context["hasInitialReport"]) || array_key_exists("hasInitialReport", $context) ? $context["hasInitialReport"] : (function () { throw new RuntimeError('Variable "hasInitialReport" does not exist.', 395, $this->source); })())) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "hidden ";
        }
        yield "py-8\">
                    ";
        // line 396
        if ((($tmp = (isset($context["hasInitialReport"]) || array_key_exists("hasInitialReport", $context) ? $context["hasInitialReport"] : (function () { throw new RuntimeError('Variable "hasInitialReport" does not exist.', 396, $this->source); })())) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 397
            yield "                        ";
            yield (isset($context["initialReportHtml"]) || array_key_exists("initialReportHtml", $context) ? $context["initialReportHtml"] : (function () { throw new RuntimeError('Variable "initialReportHtml" does not exist.', 397, $this->source); })());
            yield "
                    ";
        }
        // line 399
        yield "                </div>
            </div>
        </div>
    </section>
</main>

<div
    id=\"payment-modal\"
    class=\"hidden fixed inset-0 z-[100] overflow-y-auto bg-black/70 px-4 py-6 sm:py-10\"
>
    <div class=\"flex min-h-full items-start justify-center sm:items-center\">
        <div
            id=\"payment-modal-dialog\"
            tabindex=\"-1\"
            class=\"w-full max-w-md rounded-2xl border border-white/10 bg-slate-900 p-6 shadow-2xl\"
        >
            <h2 class=\"mb-4 text-xl font-bold text-white\">🔓 Unlock full report</h2>

            <p class=\"mb-4 text-slate-400\">
                Pay <strong id=\"payment-modal-amount-text\">9.00 USDT</strong> to unlock:
            </p>

            <ul class=\"mb-6 space-y-1 text-sm text-slate-300\">
                <li>• Full clause breakdown</li>
                <li>• Safer wording</li>
                <li>• Missing protections</li>
                <li>• PDF export</li>
            </ul>

            <div id=\"payment-modal-address\" class=\"break-all rounded-xl bg-black/40 p-3 text-center font-mono text-sm text-green-400\">
                ";
        // line 429
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["initialPayment"] ?? null), "address", [], "any", true, true, false, 429)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, (isset($context["initialPayment"]) || array_key_exists("initialPayment", $context) ? $context["initialPayment"] : (function () { throw new RuntimeError('Variable "initialPayment" does not exist.', 429, $this->source); })()), "address", [], "any", false, false, false, 429), "Wallet address will appear after report generation")) : ("Wallet address will appear after report generation")), "html", null, true);
        yield "
            </div>

            <p class=\"mt-2 text-center text-xs text-slate-500\">
                Network: TRC20
            </p>

            <input
                id=\"tx-hash-input\"
                type=\"text\"
                placeholder=\"Paste transaction hash\"
                class=\"mt-4 w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white\"
            />

            <button
                onclick=\"submitPayment()\"
                class=\"mt-4 w-full rounded-xl bg-violet-500 py-3 font-bold text-white hover:bg-violet-600\"
            >
                Submit payment
            </button>

            <button
                onclick=\"closePaymentModal()\"
                class=\"mt-2 w-full text-sm text-slate-400\"
            >
                Cancel
            </button>
        </div>
    </div>
</div>

<script>
    window.currentReportId = ";
        // line 461
        yield ((array_key_exists("initialPublicId", $context)) ? (json_encode((isset($context["initialPublicId"]) || array_key_exists("initialPublicId", $context) ? $context["initialPublicId"] : (function () { throw new RuntimeError('Variable "initialPublicId" does not exist.', 461, $this->source); })()))) : ("null"));
        yield ";
    window.currentPaymentId = ";
        // line 462
        yield (((array_key_exists("initialPayment", $context) && (isset($context["initialPayment"]) || array_key_exists("initialPayment", $context) ? $context["initialPayment"] : (function () { throw new RuntimeError('Variable "initialPayment" does not exist.', 462, $this->source); })()))) ? (json_encode(CoreExtension::getAttribute($this->env, $this->source, (isset($context["initialPayment"]) || array_key_exists("initialPayment", $context) ? $context["initialPayment"] : (function () { throw new RuntimeError('Variable "initialPayment" does not exist.', 462, $this->source); })()), "paymentId", [], "any", false, false, false, 462))) : ("null"));
        yield ";
    window.currentPaymentAddress = ";
        // line 463
        yield (((array_key_exists("initialPayment", $context) && (isset($context["initialPayment"]) || array_key_exists("initialPayment", $context) ? $context["initialPayment"] : (function () { throw new RuntimeError('Variable "initialPayment" does not exist.', 463, $this->source); })()))) ? (json_encode(CoreExtension::getAttribute($this->env, $this->source, (isset($context["initialPayment"]) || array_key_exists("initialPayment", $context) ? $context["initialPayment"] : (function () { throw new RuntimeError('Variable "initialPayment" does not exist.', 463, $this->source); })()), "address", [], "any", false, false, false, 463))) : ("null"));
        yield ";
    window.currentPaymentAmount = ";
        // line 464
        yield (((array_key_exists("initialPayment", $context) && (isset($context["initialPayment"]) || array_key_exists("initialPayment", $context) ? $context["initialPayment"] : (function () { throw new RuntimeError('Variable "initialPayment" does not exist.', 464, $this->source); })()))) ? (json_encode(CoreExtension::getAttribute($this->env, $this->source, (isset($context["initialPayment"]) || array_key_exists("initialPayment", $context) ? $context["initialPayment"] : (function () { throw new RuntimeError('Variable "initialPayment" does not exist.', 464, $this->source); })()), "amount", [], "any", false, false, false, 464))) : ("null"));
        yield ";
    window.currentPaymentCurrency = ";
        // line 465
        yield (((array_key_exists("initialPayment", $context) && (isset($context["initialPayment"]) || array_key_exists("initialPayment", $context) ? $context["initialPayment"] : (function () { throw new RuntimeError('Variable "initialPayment" does not exist.', 465, $this->source); })()))) ? (json_encode(CoreExtension::getAttribute($this->env, $this->source, (isset($context["initialPayment"]) || array_key_exists("initialPayment", $context) ? $context["initialPayment"] : (function () { throw new RuntimeError('Variable "initialPayment" does not exist.', 465, $this->source); })()), "currency", [], "any", false, false, false, 465))) : ("null"));
        yield ";
</script>

<script src=\"/assets/contract-analyzer.js\"></script>
</body>
</html>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "landing/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  555 => 465,  551 => 464,  547 => 463,  543 => 462,  539 => 461,  504 => 429,  472 => 399,  466 => 397,  464 => 396,  458 => 395,  433 => 375,  416 => 361,  410 => 358,  87 => 37,  85 => 36,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
    <title>ContractMirror.ai — Check freelance contracts before signing</title>
    <script src=\"https://cdn.tailwindcss.com\"></script>
    <style>
        html { scroll-behavior: smooth; }

        body {
            background:
                radial-gradient(circle at top center, rgba(56, 189, 248, 0.16), transparent 34%),
                radial-gradient(circle at 20% 20%, rgba(99, 102, 241, 0.18), transparent 24%),
                radial-gradient(circle at 80% 10%, rgba(59, 130, 246, 0.12), transparent 20%),
                #0b132b;
        }

        .glass {
            background: rgba(15, 23, 42, 0.72);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
        }

        .grid-fade {
            background-image:
                linear-gradient(rgba(148,163,184,.08) 1px, transparent 1px),
                linear-gradient(90deg, rgba(148,163,184,.08) 1px, transparent 1px);
            background-size: 32px 32px;
            mask-image: radial-gradient(circle at center, black 45%, transparent 90%);
            -webkit-mask-image: radial-gradient(circle at center, black 45%, transparent 90%);
        }
    </style>
</head>
<body class=\"text-slate-200 font-sans leading-relaxed antialiased\">
{% set hasInitialReport = initialReportHtml is defined and initialReportHtml is not empty %}

<div class=\"fixed inset-0 grid-fade pointer-events-none\"></div>

<header class=\"sticky top-0 z-50 border-b border-white/10 bg-slate-950/40 backdrop-blur-xl\">
    <div class=\"mx-auto flex max-w-7xl items-center justify-between px-6 py-4\">
        <a href=\"#top\" class=\"flex items-center gap-3\">
            <div class=\"h-10 w-3 rounded-full bg-gradient-to-b from-violet-400 to-cyan-400 shadow-[0_0_24px_rgba(99,102,241,.45)]\"></div>
            <span class=\"text-2xl font-black tracking-tight text-white\">
                ContractMirror<span class=\"text-violet-400\">.ai</span>
            </span>
        </a>

        <nav class=\"hidden items-center gap-8 text-sm font-semibold text-slate-300 md:flex\">
            <a href=\"#problem\" class=\"transition hover:text-white\">Why it matters</a>
            <a href=\"#how\" class=\"transition hover:text-white\">How it works</a>
            <a href=\"#report\" class=\"transition hover:text-white\">Sample report</a>
            <a href=\"#live-report\" class=\"transition hover:text-white\">Live result</a>
        </nav>

        <a href=\"#analyze\" class=\"rounded-full bg-gradient-to-r from-violet-500 to-indigo-500 px-5 py-2.5 text-sm font-bold text-white shadow-[0_0_30px_rgba(99,102,241,.35)] transition hover:-translate-y-0.5\">
            Get Started
        </a>
    </div>
</header>

<main id=\"top\">
    <section class=\"relative overflow-hidden\">
        <div class=\"mx-auto max-w-7xl px-6 pb-24 pt-20 lg:pb-28 lg:pt-28\">
            <div class=\"mx-auto max-w-5xl text-center\">
                <div class=\"mb-6 inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-sm font-medium text-cyan-200\">
                    AI contract risk analysis for freelancers, developers, designers, and agencies
                </div>

                <h1 class=\"mx-auto max-w-4xl text-5xl font-black tracking-tight text-white md:text-7xl\">
                    Check freelance contracts
                    <span class=\"bg-gradient-to-r from-violet-400 via-sky-400 to-cyan-300 bg-clip-text text-transparent\">
                        before signing
                    </span>
                </h1>

                <p class=\"mx-auto mt-6 max-w-3xl text-lg text-slate-300 md:text-xl\">
                    Upload a contract and get a clear risk score, red flags, rewrite suggestions, and a structured summary in seconds.
                    ContractMirror explains legal meaning in plain language, even when the contract is written in another language.
                </p>

                <div class=\"mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row\">
                    <a href=\"#analyze\" class=\"inline-flex min-w-[220px] items-center justify-center rounded-2xl bg-gradient-to-r from-violet-500 to-indigo-500 px-7 py-4 text-base font-bold text-white shadow-[0_0_36px_rgba(99,102,241,.35)] transition hover:-translate-y-0.5\">
                        Analyze your contract
                    </a>
                    <a href=\"#live-report\" class=\"inline-flex min-w-[220px] items-center justify-center rounded-2xl border border-white/15 bg-white/5 px-7 py-4 text-base font-bold text-slate-200 transition hover:bg-white/10\">
                        See live report layout
                    </a>
                </div>
            </div>

            <div class=\"mt-16 grid gap-8 lg:grid-cols-[1.1fr_.9fr] lg:items-start\">
                <div id=\"analyze\" class=\"glass rounded-[28px] border border-white/10 p-8 shadow-2xl shadow-slate-950/40\">
                    <div class=\"mb-6 flex items-start justify-between gap-4\">
                        <div>
                            <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-slate-400\">Upload & scan</div>
                            <h2 class=\"mt-2 text-2xl font-bold text-white\">Drop your PDF, DOCX, or TXT here</h2>
                            <p class=\"mt-2 text-slate-400\">Private by default. Encrypted in transit. Max file size 10 MB in MVP.</p>
                        </div>
                        <div class=\"rounded-2xl border border-violet-400/20 bg-violet-400/10 px-3 py-2 text-xs font-bold uppercase tracking-[0.2em] text-violet-200\">
                            Fast AI review
                        </div>
                    </div>

                    <form
                        id=\"analyze-contract-form\"
                        method=\"POST\"
                        enctype=\"multipart/form-data\"
                        class=\"rounded-[24px] border-2 border-dashed border-slate-700 bg-slate-900/60 p-8 text-center transition hover:border-violet-400/60\"
                    >
                        <div class=\"mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-3xl bg-slate-800 text-4xl shadow-inner\">
                            ☁️
                        </div>

                        <p class=\"text-xl font-bold text-white\">Drop your contract here</p>
                        <p class=\"mt-2 text-slate-400\">Choose a file and get a clear verdict, top risks, and safer wording suggestions.</p>

                        <input
                            id=\"contract-file-input\"
                            type=\"file\"
                            name=\"contractFile\"
                            class=\"hidden\"
                            accept=\".pdf,.docx,.txt\"
                        >

                        <div class=\"mt-6\">
                            <label for=\"preferredLanguage\" class=\"mb-2 block text-sm font-medium text-slate-300\">
                                Analysis language
                            </label>

                            <select
                                id=\"preferredLanguage\"
                                name=\"preferredLanguage\"
                                class=\"w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-slate-200 outline-none transition focus:border-violet-400\"
                            >
                                <option value=\"English\">English</option>
                                <option value=\"Ukrainian\">Ukrainian</option>
                                <option value=\"German\">German</option>
                                <option value=\"Spanish\">Spanish</option>
                                <option value=\"Italian\">Italian</option>
                                <option value=\"French\">French</option>
                                <option value=\"Turkish\">Turkish</option>
                                <option value=\"Greek\">Greek</option>
                                <option value=\"Polish\">Polish</option>
                                <option value=\"Russian\">Russian</option>
                            </select>
                        </div>

                        <div id=\"selected-file-name\" class=\"mt-4 text-sm text-slate-400\">
                            No file selected
                        </div>

                        <div class=\"mt-8 grid gap-3 sm:grid-cols-2\">
                            <button
                                type=\"button\"
                                id=\"upload-contract-trigger\"
                                class=\"rounded-2xl bg-gradient-to-r from-violet-500 to-indigo-500 px-6 py-4 font-bold text-white shadow-[0_0_24px_rgba(99,102,241,.3)] transition hover:-translate-y-0.5\"
                            >
                                Upload contract
                            </button>

                            <button
                                type=\"submit\"
                                id=\"analyze-submit-button\"
                                class=\"rounded-2xl border border-white/10 bg-white/5 px-6 py-4 font-bold text-slate-200 transition hover:bg-white/10\"
                            >
                                Analyze contract
                            </button>
                        </div>

                        <div id=\"form-status\" class=\"mt-5 hidden rounded-2xl border px-4 py-3 text-sm\"></div>

                        <p class=\"mt-5 text-xs uppercase tracking-[0.24em] text-slate-500\">
                            Informational AI analysis. Not legal advice.
                        </p>
                    </form>

                    <div class=\"mt-6 text-center\">
                        <p class=\"text-sm text-slate-400 mb-2\">
                            See a real example report
                        </p>

                        <a
                            href=\"/demo/contract-report-example.pdf\"
                            target=\"_blank\"
                            class=\"inline-flex items-center justify-center rounded-xl border border-white/10 bg-white/5 px-5 py-3 text-sm font-semibold text-slate-200 transition hover:bg-white/10\"
                        >
                            View Sample PDF →
                        </a>

                        <p class=\"mt-2 text-xs text-slate-500\">
                            No signup required • Takes ~30 seconds
                        </p>
                    </div>

                    <div class=\"mt-8 grid gap-3 sm:grid-cols-3\">
                        <div class=\"rounded-2xl border border-white/10 bg-white/5 p-4\">
                            <div class=\"text-sm text-slate-400\">Average scan time</div>
                            <div class=\"mt-2 text-xl font-bold text-white\">~30 sec</div>
                        </div>
                        <div class=\"rounded-2xl border border-white/10 bg-white/5 p-4\">
                            <div class=\"text-sm text-slate-400\">Output</div>
                            <div class=\"mt-2 text-xl font-bold text-white\">Risk + fixes</div>
                        </div>
                        <div class=\"rounded-2xl border border-white/10 bg-white/5 p-4\">
                            <div class=\"text-sm text-slate-400\">Built for</div>
                            <div class=\"mt-2 text-xl font-bold text-white\">Freelancers</div>
                        </div>
                    </div>
                </div>

                <section id=\"report\" class=\"glass rounded-[28px] border border-white/10 p-6 shadow-2xl shadow-slate-950/40\">
                    <div class=\"flex items-center justify-between gap-4 border-b border-white/10 pb-5\">
                        <div>
                            <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-slate-400\">Sample output</div>
                            <h3 class=\"mt-2 text-xl font-bold text-white\">Contract risk snapshot</h3>
                        </div>
                        <span class=\"rounded-full border border-orange-400/20 bg-orange-400/10 px-3 py-1 text-xs font-bold uppercase tracking-[0.18em] text-orange-300\">
                            Medium risk
                        </span>
                    </div>

                    <div class=\"mt-6 rounded-[24px] border border-white/10 bg-slate-950/50 p-6\">
                        <div class=\"flex items-end justify-between gap-4\">
                            <div>
                                <div class=\"text-sm text-slate-400\">Contract Risk Score</div>
                                <div class=\"mt-2 text-5xl font-black tracking-tight text-white\">
                                    6.4<span class=\"text-xl text-slate-500\"> / 10</span>
                                </div>
                            </div>
                            <div class=\"rounded-2xl border border-violet-400/20 bg-violet-400/10 px-3 py-2 text-sm font-bold text-violet-200\">
                                Needs review
                            </div>
                        </div>

                        <div class=\"mt-6\">
                            <div class=\"mb-2 flex items-center justify-between text-xs font-bold uppercase tracking-[0.18em] text-slate-400\">
                                <span>Safe</span>
                                <span>Warning</span>
                                <span>Dangerous</span>
                            </div>
                            <div class=\"h-3 overflow-hidden rounded-full bg-slate-800\">
                                <div class=\"h-full w-[64%] rounded-full bg-gradient-to-r from-emerald-400 via-amber-400 to-red-500\"></div>
                            </div>
                        </div>

                        <div class=\"mt-6 space-y-4\">
                            <div class=\"rounded-2xl border border-red-400/20 bg-red-500/10 p-4\">
                                <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-red-300\">Flagged clause</div>
                                <p class=\"mt-2 text-sm text-slate-200\">
                                    “Contractor agrees to modify deliverables until the client is fully satisfied.”
                                </p>
                            </div>

                            <div class=\"rounded-2xl border border-cyan-400/20 bg-cyan-400/10 p-4\">
                                <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-cyan-200\">Plain explanation</div>
                                <p class=\"mt-2 text-sm text-slate-100\">
                                    This wording gives the client very broad power to keep asking for changes without a clear stopping point or additional payment terms.
                                </p>
                            </div>

                            <div class=\"rounded-2xl border border-violet-400/20 bg-violet-400/10 p-4\">
                                <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-violet-200\">Suggested rewrite</div>
                                <p class=\"mt-2 text-sm text-slate-100\">
                                    “The agreed price includes up to 2 revision rounds. Additional revision requests are billed separately at the contractor’s standard hourly rate.”
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <div class=\"mt-10 flex flex-wrap items-center justify-center gap-4 text-sm text-slate-400\">
                <span class=\"rounded-full border border-white/10 bg-white/5 px-4 py-2\">Built for developers</span>
                <span class=\"rounded-full border border-white/10 bg-white/5 px-4 py-2\">Designers</span>
                <span class=\"rounded-full border border-white/10 bg-white/5 px-4 py-2\">Agencies</span>
                <span class=\"rounded-full border border-white/10 bg-white/5 px-4 py-2\">Remote pros</span>
                <span class=\"rounded-full border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-cyan-200\">
                    Cross-language contract support
                </span>
            </div>
        </div>
    </section>

    <section id=\"problem\" class=\"py-24\">
        <div class=\"mx-auto max-w-7xl px-6\">
            <div class=\"grid gap-8 lg:grid-cols-[1fr_1fr] lg:items-center\">
                <div>
                    <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-cyan-300\">Cross-language clarity</div>
                    <h2 class=\"mt-4 text-4xl font-black tracking-tight text-white md:text-5xl\">
                        Understand contracts across languages
                    </h2>
                    <p class=\"mt-5 text-lg text-slate-400\">
                        Upload contracts written in German, Polish, Spanish, or English. ContractMirror explains the legal meaning
                        in plain language, so users can understand what they are agreeing to without guessing or translating clause by clause.
                    </p>
                </div>
                <div class=\"grid gap-4 sm:grid-cols-3\">
                    <div class=\"rounded-3xl border border-white/10 bg-white/5 p-5\">
                        <div class=\"text-sm uppercase tracking-[0.2em] text-slate-400\">Original clause</div>
                        <div class=\"mt-3 text-sm text-white\">Legal wording as written in the contract.</div>
                    </div>
                    <div class=\"rounded-3xl border border-cyan-400/20 bg-cyan-400/10 p-5\">
                        <div class=\"text-sm uppercase tracking-[0.2em] text-cyan-200\">Plain explanation</div>
                        <div class=\"mt-3 text-sm text-cyan-50\">Human-readable meaning, in the user’s preferred language.</div>
                    </div>
                    <div class=\"rounded-3xl border border-violet-400/20 bg-violet-400/10 p-5\">
                        <div class=\"text-sm uppercase tracking-[0.2em] text-violet-200\">Safer wording</div>
                        <div class=\"mt-3 text-sm text-violet-50\">Concrete wording the user can propose back.</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id=\"how\" class=\"pb-24\">
        <div class=\"mx-auto max-w-7xl px-6\">
            <div class=\"mb-8\">
                <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-violet-300\">How it works</div>
                <h2 class=\"mt-4 text-4xl font-black tracking-tight text-white md:text-5xl\">
                    From upload to decision in minutes
                </h2>
            </div>
            <div class=\"grid gap-4 md:grid-cols-3\">
                <div class=\"rounded-3xl border border-white/10 bg-white/5 p-6\">
                    <div class=\"mb-3 text-sm font-bold uppercase tracking-[0.18em] text-cyan-200\">1. Upload</div>
                    <p class=\"text-slate-300\">Upload a PDF, DOCX, or TXT contract and choose the output language.</p>
                </div>
                <div class=\"rounded-3xl border border-white/10 bg-white/5 p-6\">
                    <div class=\"mb-3 text-sm font-bold uppercase tracking-[0.18em] text-cyan-200\">2. Analyze</div>
                    <p class=\"text-slate-300\">ContractMirror extracts the text, analyzes risk, and builds a structured report.</p>
                </div>
                <div class=\"rounded-3xl border border-white/10 bg-white/5 p-6\">
                    <div class=\"mb-3 text-sm font-bold uppercase tracking-[0.18em] text-cyan-200\">3. Decide</div>
                    <p class=\"text-slate-300\">See the verdict, understand why it matters, and use safer wording suggestions.</p>
                </div>
            </div>
        </div>
    </section>

    <section id=\"live-report\" class=\"pb-24\">
        <div class=\"mx-auto max-w-7xl px-6\">
            <div class=\"mb-8 max-w-3xl\">
                <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-violet-300\">Live report</div>
                <h2 class=\"mt-4 text-4xl font-black tracking-tight text-white md:text-5xl\">
                    Beautiful verdict view, not raw JSON
                </h2>
                <p class=\"mt-4 text-lg text-slate-400\">
                    The analysis result appears here after upload, with a simple view for quick decisions and a detailed view for clause-by-clause review.
                </p>
            </div>

            <div id=\"report-shell\" class=\"glass rounded-[32px] border border-white/10 p-6 shadow-2xl shadow-slate-950/40\">
                <div class=\"flex flex-col gap-4 border-b border-white/10 pb-6 md:flex-row md:items-center md:justify-between\">
                    <div>
                        <div class=\"text-sm font-semibold uppercase tracking-[0.24em] text-slate-400\">Analysis report</div>
                        <h3 id=\"report-title\" class=\"mt-2 text-2xl font-bold text-white\">
                            {{ hasInitialReport ? (initialReportTitle|default('Contract analysis report')) : 'No report yet' }}
                        </h3>
                        <p id=\"report-subtitle\" class=\"mt-2 text-slate-400\">
                            {{ hasInitialReport ? (initialReportSubtitle|default('Review the verdict, risks, and suggested fixes.')) : 'Upload a contract above and the structured report will appear here.' }}
                        </p>
                    </div>

                    <div class=\"flex gap-3\">
                        <button id=\"simple-view-button\" type=\"button\" class=\"rounded-2xl border border-cyan-400/20 bg-cyan-400/10 px-4 py-2 text-sm font-bold text-cyan-100\">
                            Simple view
                        </button>
                        <button id=\"detailed-view-button\" type=\"button\" class=\"rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-bold text-slate-300\">
                            Detailed view
                        </button>
                    </div>
                </div>

                <div id=\"report-empty-state\" class=\"{% if hasInitialReport %}hidden {% endif %}py-12 text-center\">
                    <div class=\"mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-slate-800 text-3xl\">🪞</div>
                    <h4 class=\"mt-5 text-xl font-bold text-white\">Ready for your first contract</h4>
                    <p class=\"mx-auto mt-3 max-w-2xl text-slate-400\">
                        You will get a risk score, plain-language summary, top issues, missing protections, and a final recommendation.
                    </p>
                </div>

                <div id=\"report-loading-state\" class=\"hidden py-12\">
                    <div class=\"mx-auto max-w-3xl animate-pulse space-y-4\">
                        <div class=\"h-6 w-48 rounded-xl bg-white/10\"></div>
                        <div class=\"h-20 rounded-3xl bg-white/5\"></div>
                        <div class=\"grid gap-4 md:grid-cols-3\">
                            <div class=\"h-32 rounded-3xl bg-white/5\"></div>
                            <div class=\"h-32 rounded-3xl bg-white/5\"></div>
                            <div class=\"h-32 rounded-3xl bg-white/5\"></div>
                        </div>
                    </div>
                </div>

                <div id=\"report-content\" class=\"{% if not hasInitialReport %}hidden {% endif %}py-8\">
                    {% if hasInitialReport %}
                        {{ initialReportHtml|raw }}
                    {% endif %}
                </div>
            </div>
        </div>
    </section>
</main>

<div
    id=\"payment-modal\"
    class=\"hidden fixed inset-0 z-[100] overflow-y-auto bg-black/70 px-4 py-6 sm:py-10\"
>
    <div class=\"flex min-h-full items-start justify-center sm:items-center\">
        <div
            id=\"payment-modal-dialog\"
            tabindex=\"-1\"
            class=\"w-full max-w-md rounded-2xl border border-white/10 bg-slate-900 p-6 shadow-2xl\"
        >
            <h2 class=\"mb-4 text-xl font-bold text-white\">🔓 Unlock full report</h2>

            <p class=\"mb-4 text-slate-400\">
                Pay <strong id=\"payment-modal-amount-text\">9.00 USDT</strong> to unlock:
            </p>

            <ul class=\"mb-6 space-y-1 text-sm text-slate-300\">
                <li>• Full clause breakdown</li>
                <li>• Safer wording</li>
                <li>• Missing protections</li>
                <li>• PDF export</li>
            </ul>

            <div id=\"payment-modal-address\" class=\"break-all rounded-xl bg-black/40 p-3 text-center font-mono text-sm text-green-400\">
                {{ initialPayment.address|default('Wallet address will appear after report generation') }}
            </div>

            <p class=\"mt-2 text-center text-xs text-slate-500\">
                Network: TRC20
            </p>

            <input
                id=\"tx-hash-input\"
                type=\"text\"
                placeholder=\"Paste transaction hash\"
                class=\"mt-4 w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white\"
            />

            <button
                onclick=\"submitPayment()\"
                class=\"mt-4 w-full rounded-xl bg-violet-500 py-3 font-bold text-white hover:bg-violet-600\"
            >
                Submit payment
            </button>

            <button
                onclick=\"closePaymentModal()\"
                class=\"mt-2 w-full text-sm text-slate-400\"
            >
                Cancel
            </button>
        </div>
    </div>
</div>

<script>
    window.currentReportId = {{ initialPublicId is defined ? initialPublicId|json_encode|raw : 'null' }};
    window.currentPaymentId = {{ initialPayment is defined and initialPayment ? initialPayment.paymentId|json_encode|raw : 'null' }};
    window.currentPaymentAddress = {{ initialPayment is defined and initialPayment ? initialPayment.address|json_encode|raw : 'null' }};
    window.currentPaymentAmount = {{ initialPayment is defined and initialPayment ? initialPayment.amount|json_encode|raw : 'null' }};
    window.currentPaymentCurrency = {{ initialPayment is defined and initialPayment ? initialPayment.currency|json_encode|raw : 'null' }};
</script>

<script src=\"/assets/contract-analyzer.js\"></script>
</body>
</html>
", "landing/index.html.twig", "/var/www/html/templates/landing/index.html.twig");
    }
}
