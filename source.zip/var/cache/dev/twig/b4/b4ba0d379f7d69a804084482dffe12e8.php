<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* contract/_report_issue_card.html.twig */
class __TwigTemplate_d8eedacc9c399931c4604f16e1f9c69a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contract/_report_issue_card.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contract/_report_issue_card.html.twig"));

        // line 1
        yield "
<article class=\"rounded-[28px] border border-white/10 bg-white/5 p-6\">

    <div class=\"flex flex-col gap-4 md:flex-row md:items-start md:justify-between\">
        <div>
            <div class=\"mb-2 flex flex-wrap gap-2\">
                <span class=\"rounded-full border px-3 py-1 text-xs font-bold uppercase tracking-[0.18em]
                    ";
        // line 8
        if ((CoreExtension::getAttribute($this->env, $this->source, (isset($context["issue"]) || array_key_exists("issue", $context) ? $context["issue"] : (function () { throw new RuntimeError('Variable "issue" does not exist.', 8, $this->source); })()), "severity", [], "any", false, false, false, 8) == "HIGH")) {
            yield "border-red-400/20 bg-red-500/10 text-red-200
                    ";
        } elseif ((CoreExtension::getAttribute($this->env, $this->source,         // line 9
(isset($context["issue"]) || array_key_exists("issue", $context) ? $context["issue"] : (function () { throw new RuntimeError('Variable "issue" does not exist.', 9, $this->source); })()), "severity", [], "any", false, false, false, 9) == "LOW")) {
            yield "border-emerald-400/20 bg-emerald-500/10 text-emerald-200
                    ";
        } else {
            // line 10
            yield "border-amber-400/20 bg-amber-500/10 text-amber-200";
        }
        yield "\">
                    ";
        // line 11
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["issue"]) || array_key_exists("issue", $context) ? $context["issue"] : (function () { throw new RuntimeError('Variable "issue" does not exist.', 11, $this->source); })()), "severity", [], "any", false, false, false, 11), "html", null, true);
        yield "
                </span>
                <span class=\"rounded-full border border-white/10 bg-slate-950/40 px-3 py-1 text-xs text-slate-300\">";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["issue"]) || array_key_exists("issue", $context) ? $context["issue"] : (function () { throw new RuntimeError('Variable "issue" does not exist.', 13, $this->source); })()), "category", [], "any", false, false, false, 13), "html", null, true);
        yield "</span>
            </div>
            <h4 class=\"text-xl font-bold text-white\">";
        // line 15
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["issue"]) || array_key_exists("issue", $context) ? $context["issue"] : (function () { throw new RuntimeError('Variable "issue" does not exist.', 15, $this->source); })()), "title", [], "any", false, false, false, 15), "html", null, true);
        yield "</h4>
        </div>
    </div>

    <div class=\"rounded-2xl border border-red-400/20 bg-red-500/10 p-4 mt-4\">
        <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-red-300\">
            What you risk
        </div>
        <p class=\"mt-2 text-sm text-slate-100\">
            ";
        // line 24
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["issue"]) || array_key_exists("issue", $context) ? $context["issue"] : (function () { throw new RuntimeError('Variable "issue" does not exist.', 24, $this->source); })()), "impact", [], "any", false, false, false, 24), "html", null, true);
        yield "
        </p>
    </div>

    <div class=\"mt-5 grid gap-4 lg:grid-cols-2\">
        <div class=\"rounded-2xl border border-red-400/20 bg-red-500/10 p-4\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-red-300\">Original clause</div>
            <p class=\"mt-2 whitespace-pre-line text-sm text-slate-100\">";
        // line 31
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["issue"]) || array_key_exists("issue", $context) ? $context["issue"] : (function () { throw new RuntimeError('Variable "issue" does not exist.', 31, $this->source); })()), "originalClause", [], "any", false, false, false, 31), "html", null, true);
        yield "</p>
        </div>

        <div class=\"rounded-2xl border border-cyan-400/20 bg-cyan-400/10 p-4\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-cyan-200\">Plain explanation</div>
            <p class=\"mt-2 text-sm text-slate-100\">";
        // line 36
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["issue"]) || array_key_exists("issue", $context) ? $context["issue"] : (function () { throw new RuntimeError('Variable "issue" does not exist.', 36, $this->source); })()), "plainExplanation", [], "any", false, false, false, 36), "html", null, true);
        yield "</p>
        </div>
    </div>

    <div class=\"mt-4 grid gap-4 lg:grid-cols-2\">
        <div class=\"rounded-2xl border border-amber-400/20 bg-amber-500/10 p-4\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-amber-200\">Why it matters</div>
            <p class=\"mt-2 text-sm text-slate-100\">";
        // line 43
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["issue"]) || array_key_exists("issue", $context) ? $context["issue"] : (function () { throw new RuntimeError('Variable "issue" does not exist.', 43, $this->source); })()), "whyItMatters", [], "any", false, false, false, 43), "html", null, true);
        yield "</p>
        </div>

        <div class=\"rounded-2xl border border-violet-400/20 bg-violet-400/10 p-4\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-violet-200\">Suggested safer wording</div>
            <p class=\"mt-2 whitespace-pre-line text-sm text-slate-100\">";
        // line 48
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["issue"]) || array_key_exists("issue", $context) ? $context["issue"] : (function () { throw new RuntimeError('Variable "issue" does not exist.', 48, $this->source); })()), "suggestedRewrite", [], "any", false, false, false, 48), "html", null, true);
        yield "</p>
        </div>
    </div>

</article>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "contract/_report_issue_card.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  129 => 48,  121 => 43,  111 => 36,  103 => 31,  93 => 24,  81 => 15,  76 => 13,  71 => 11,  66 => 10,  61 => 9,  57 => 8,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("
<article class=\"rounded-[28px] border border-white/10 bg-white/5 p-6\">

    <div class=\"flex flex-col gap-4 md:flex-row md:items-start md:justify-between\">
        <div>
            <div class=\"mb-2 flex flex-wrap gap-2\">
                <span class=\"rounded-full border px-3 py-1 text-xs font-bold uppercase tracking-[0.18em]
                    {% if issue.severity == 'HIGH' %}border-red-400/20 bg-red-500/10 text-red-200
                    {% elseif issue.severity == 'LOW' %}border-emerald-400/20 bg-emerald-500/10 text-emerald-200
                    {% else %}border-amber-400/20 bg-amber-500/10 text-amber-200{% endif %}\">
                    {{ issue.severity }}
                </span>
                <span class=\"rounded-full border border-white/10 bg-slate-950/40 px-3 py-1 text-xs text-slate-300\">{{ issue.category }}</span>
            </div>
            <h4 class=\"text-xl font-bold text-white\">{{ issue.title }}</h4>
        </div>
    </div>

    <div class=\"rounded-2xl border border-red-400/20 bg-red-500/10 p-4 mt-4\">
        <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-red-300\">
            What you risk
        </div>
        <p class=\"mt-2 text-sm text-slate-100\">
            {{ issue.impact }}
        </p>
    </div>

    <div class=\"mt-5 grid gap-4 lg:grid-cols-2\">
        <div class=\"rounded-2xl border border-red-400/20 bg-red-500/10 p-4\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-red-300\">Original clause</div>
            <p class=\"mt-2 whitespace-pre-line text-sm text-slate-100\">{{ issue.originalClause }}</p>
        </div>

        <div class=\"rounded-2xl border border-cyan-400/20 bg-cyan-400/10 p-4\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-cyan-200\">Plain explanation</div>
            <p class=\"mt-2 text-sm text-slate-100\">{{ issue.plainExplanation }}</p>
        </div>
    </div>

    <div class=\"mt-4 grid gap-4 lg:grid-cols-2\">
        <div class=\"rounded-2xl border border-amber-400/20 bg-amber-500/10 p-4\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-amber-200\">Why it matters</div>
            <p class=\"mt-2 text-sm text-slate-100\">{{ issue.whyItMatters }}</p>
        </div>

        <div class=\"rounded-2xl border border-violet-400/20 bg-violet-400/10 p-4\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em] text-violet-200\">Suggested safer wording</div>
            <p class=\"mt-2 whitespace-pre-line text-sm text-slate-100\">{{ issue.suggestedRewrite }}</p>
        </div>
    </div>

</article>
", "contract/_report_issue_card.html.twig", "/var/www/html/templates/contract/_report_issue_card.html.twig");
    }
}
