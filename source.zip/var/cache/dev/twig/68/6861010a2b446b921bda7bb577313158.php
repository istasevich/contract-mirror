<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* contract/_report_header.html.twig */
class __TwigTemplate_d1858b3a3e472c1b3a25d04b0b4f81c1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contract/_report_header.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contract/_report_header.html.twig"));

        // line 1
        yield "
<section class=\"rounded-[28px] border border-white/10 bg-slate-950/40 p-6\">
    <div class=\"flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between\">
        <div>
            <div class=\"text-sm font-semibold uppercase tracking-[0.18em] text-slate-400\">Contract analysis result</div>
            <h2 class=\"mt-3 text-3xl font-black tracking-tight text-white\">";
        // line 6
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 6, $this->source); })()), "documentName", [], "any", false, false, false, 6), "html", null, true);
        yield "</h2>
            <div class=\"mt-4 flex flex-wrap gap-2\">
                <span class=\"rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300\">Language: ";
        // line 8
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 8, $this->source); })()), "language", [], "any", false, false, false, 8), "html", null, true);
        yield "</span>
                <span class=\"rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300\">Type: ";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 9, $this->source); })()), "documentType", [], "any", false, false, false, 9), "html", null, true);
        yield "</span>
            </div>
            <div class=\"mt-4 rounded-xl border border-red-400/20 bg-red-500/10 px-4 py-3 text-sm text-red-200 max-w-sm\">
                ⚠️ ";
        // line 12
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 12, $this->source); })()), "riskSummary", [], "any", false, false, false, 12), "html", null, true);
        yield "
            </div>
                ";
        // line 14
        if ((($tmp = (isset($context["publicId"]) || array_key_exists("publicId", $context) ? $context["publicId"] : (function () { throw new RuntimeError('Variable "publicId" does not exist.', 14, $this->source); })())) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 15
            yield "                <div class=\"mt-6\">
                    <a
                        href=\"";
            // line 17
            yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_contract_report_pdf", ["publicId" => (isset($context["publicId"]) || array_key_exists("publicId", $context) ? $context["publicId"] : (function () { throw new RuntimeError('Variable "publicId" does not exist.', 17, $this->source); })())]), "html", null, true);
            yield "\"
                        target=\"_blank\"
                        class=\"inline-flex items-center justify-center rounded-2xl border border-cyan-400/20 bg-cyan-400/10 px-5 py-3 text-sm font-bold text-cyan-100 transition hover:bg-cyan-400/20\"
                    >
                        Download PDF
                    </a>
                </div>
            ";
        }
        // line 25
        yield "
        </div>

        <div class=\"rounded-[24px] border px-5 py-4 text-right
            ";
        // line 29
        if ((CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 29, $this->source); })()), "overallRisk", [], "any", false, false, false, 29) == "HIGH")) {
            yield "border-red-400/20 bg-red-500/10 text-red-200
            ";
        } elseif ((CoreExtension::getAttribute($this->env, $this->source,         // line 30
(isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 30, $this->source); })()), "overallRisk", [], "any", false, false, false, 30) == "LOW")) {
            yield "border-emerald-400/20 bg-emerald-500/10 text-emerald-200
            ";
        } else {
            // line 31
            yield "border-amber-400/20 bg-amber-500/10 text-amber-200";
        }
        yield "\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em]\">Risk score</div>
            <div class=\"mt-2 text-4xl font-black tracking-tight\">";
        // line 33
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 33, $this->source); })()), "riskScore", [], "any", false, false, false, 33), "html", null, true);
        yield "/100</div>
            <div class=\"mt-2 text-sm font-bold uppercase tracking-[0.18em]\">";
        // line 34
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new RuntimeError('Variable "report" does not exist.', 34, $this->source); })()), "overallRisk", [], "any", false, false, false, 34), "html", null, true);
        yield "</div>
        </div>
    </div>
</section>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "contract/_report_header.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  117 => 34,  113 => 33,  107 => 31,  102 => 30,  98 => 29,  92 => 25,  81 => 17,  77 => 15,  75 => 14,  70 => 12,  64 => 9,  60 => 8,  55 => 6,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("
<section class=\"rounded-[28px] border border-white/10 bg-slate-950/40 p-6\">
    <div class=\"flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between\">
        <div>
            <div class=\"text-sm font-semibold uppercase tracking-[0.18em] text-slate-400\">Contract analysis result</div>
            <h2 class=\"mt-3 text-3xl font-black tracking-tight text-white\">{{ report.documentName }}</h2>
            <div class=\"mt-4 flex flex-wrap gap-2\">
                <span class=\"rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300\">Language: {{ report.language }}</span>
                <span class=\"rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300\">Type: {{ report.documentType }}</span>
            </div>
            <div class=\"mt-4 rounded-xl border border-red-400/20 bg-red-500/10 px-4 py-3 text-sm text-red-200 max-w-sm\">
                ⚠️ {{ report.riskSummary }}
            </div>
                {% if publicId  %}
                <div class=\"mt-6\">
                    <a
                        href=\"{{ path('app_contract_report_pdf', { publicId: publicId }) }}\"
                        target=\"_blank\"
                        class=\"inline-flex items-center justify-center rounded-2xl border border-cyan-400/20 bg-cyan-400/10 px-5 py-3 text-sm font-bold text-cyan-100 transition hover:bg-cyan-400/20\"
                    >
                        Download PDF
                    </a>
                </div>
            {% endif %}

        </div>

        <div class=\"rounded-[24px] border px-5 py-4 text-right
            {% if report.overallRisk == 'HIGH' %}border-red-400/20 bg-red-500/10 text-red-200
            {% elseif report.overallRisk == 'LOW' %}border-emerald-400/20 bg-emerald-500/10 text-emerald-200
            {% else %}border-amber-400/20 bg-amber-500/10 text-amber-200{% endif %}\">
            <div class=\"text-xs font-bold uppercase tracking-[0.18em]\">Risk score</div>
            <div class=\"mt-2 text-4xl font-black tracking-tight\">{{ report.riskScore }}/100</div>
            <div class=\"mt-2 text-sm font-bold uppercase tracking-[0.18em]\">{{ report.overallRisk }}</div>
        </div>
    </div>
</section>
", "contract/_report_header.html.twig", "/var/www/html/templates/contract/_report_header.html.twig");
    }
}
