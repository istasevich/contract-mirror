<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/api/contracts/analyze' => [[['_route' => 'app_contract_analyze', '_controller' => 'App\\Feature\\ContractAnalyzer\\Controller\\AnalyzeContractController'], null, ['POST' => 0], null, false, false, null]],
        '/' => [[['_route' => 'landing', '_controller' => 'App\\Feature\\ContractAnalyzer\\Controller\\LandingController::index'], null, ['GET' => 0], null, false, false, null]],
        '/api/contracts/rewrite-clause' => [[['_route' => 'app_contract_rewrite_clause', '_controller' => 'App\\Feature\\ContractAnalyzer\\Controller\\RewriteClauseController'], null, ['POST' => 0], null, false, false, null]],
        '/_wdt/styles' => [[['_route' => '_wdt_stylesheet', '_controller' => 'web_profiler.controller.profiler::toolbarStylesheetAction'], null, null, null, false, false, null]],
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/xdebug' => [[['_route' => '_profiler_xdebug', '_controller' => 'web_profiler.controller.profiler::xdebugAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/r/([^/]++)(?'
                    .'|/pdf(*:25)'
                    .'|(*:32)'
                .')'
                .'|/api/payments/([^/]++)/s(?'
                    .'|tatus(*:72)'
                    .'|ubmit(*:84)'
                .')'
                .'|/_(?'
                    .'|wdt/([^/]++)(*:109)'
                    .'|profiler/(?'
                        .'|font/([^/\\.]++)\\.woff2(*:151)'
                        .'|([^/]++)(?'
                            .'|/(?'
                                .'|search/results(*:188)'
                                .'|router(*:202)'
                                .'|exception(?'
                                    .'|(*:222)'
                                    .'|\\.css(*:235)'
                                .')'
                            .')'
                            .'|(*:245)'
                        .')'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        25 => [[['_route' => 'app_contract_report_pdf', '_controller' => 'App\\Feature\\ContractAnalyzer\\Controller\\DownloadContractReportPdfController'], ['publicId'], ['GET' => 0], null, false, false, null]],
        32 => [[['_route' => 'app_contract_report_view', '_controller' => 'App\\Feature\\ContractAnalyzer\\Controller\\ViewContractReportController'], ['publicId'], ['GET' => 0], null, false, true, null]],
        72 => [[['_route' => 'app_payment_status', '_controller' => 'App\\Feature\\Payment\\Controller\\PaymentStatusController'], ['paymentId'], ['GET' => 0], null, false, false, null]],
        84 => [[['_route' => 'app_payment_submit_hash', '_controller' => 'App\\Feature\\Payment\\Controller\\SubmitPaymentHashController'], ['paymentId'], ['POST' => 0], null, false, false, null]],
        109 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        151 => [[['_route' => '_profiler_font', '_controller' => 'web_profiler.controller.profiler::fontAction'], ['fontName'], null, null, false, false, null]],
        188 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        202 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        222 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        235 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        245 => [
            [['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
